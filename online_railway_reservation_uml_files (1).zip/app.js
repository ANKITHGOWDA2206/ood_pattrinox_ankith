// Small accessibility and print helpers for the UML diagram.
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".uml").forEach((box) => {
    box.tabIndex = 0;
    box.setAttribute("role", "group");
    const name = box.querySelector("h2")?.textContent.trim() || "UML class";
    box.setAttribute("aria-label", `${name} class: attributes and operations`);
  });

  // Press P to open the browser print dialog and save the diagram as PDF.
  document.addEventListener("keydown", (event) => {
    if (event.key.toLowerCase() === "p" &&
        !["INPUT", "TEXTAREA"].includes(document.activeElement.tagName)) {
      window.print();
    }
  });
});
