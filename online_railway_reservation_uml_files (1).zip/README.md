# Online Railway Reservation System — UML Class Diagram

A simple HTML, CSS and JavaScript presentation of the UML class pattern supplied in the project image.

## Project files

- **index.html** — contains the page structure and all UML class names, attributes and operations.
- **style.css** — creates the grid-paper background, white class boxes, black borders and diagram layout.
- **app.js** — adds accessibility labels and a `P` keyboard shortcut for printing.
- **README.md** — project documentation.

## Classes included

1. Train
2. Schedule
3. Ticket
4. Passenger
5. Reservation
6. Payment
7. Cancellation
8. User
9. Admin
10. Agent

## Run the project

1. Keep all four files in the same folder.
2. Open `index.html` in Chrome, Edge or Firefox.
3. To save a PDF, press **P** or open the browser print menu and choose **Save as PDF**.

## Design

- The page uses a white graph-paper background with light grey grid lines.
- Every UML class box has a white background, black border and black text.
- Each class is divided into its name, attributes and operations.

## Scope

This is a front-end UML diagram display. It does not implement actual train search, ticket booking, database storage, authentication or payment processing. The lines and multiplicities are visual representations of the relationships in the supplied pattern.
